using UnityEngine;

public enum Speeds { Slow = 0, Normal = 1, Fast = 2, Faster = 3, Fastest = 4 }

public class Movement : MonoBehaviour
{
    private Rigidbody2D rb;
    public SpeedManager speedManager;

    private float gravityDirection = 1f; // 1 = down, -1 = up
    public float baseGravity = 5f;       // gravity strength

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.gravityScale = baseGravity * gravityDirection;
    }

    void Update()
    {
        // Constant forward movement
        transform.position += Vector3.right * speedManager.GetSpeed() * Time.deltaTime;

        // Input check
        if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0))
        {
            FlipGravity();
        }
    }

    private void FlipGravity()
    {
        // Flip gravity direction instantly
        gravityDirection *= -1;
        rb.gravityScale = baseGravity * gravityDirection;

        // Reset vertical velocity for snappy response
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, 0);

        // Rotate sprite 180 around Z-axis
        transform.Rotate(0f, 0f, 180f);
    }
}